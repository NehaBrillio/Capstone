package com.healthifyme.capstoneJPA.model;

public class Calories {

}
