package com.healthifyme.capstoneJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CapstoneJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoneJpaApplication.class, args);
	}

}
