package com.healthifyme.capstoneJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstoneJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
